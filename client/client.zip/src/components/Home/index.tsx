import styles from "./Home.module.scss";
import Hero from "./Hero";
import SearchSection from "./SearchSection";
import BottomNav from "../BottomNav";

export default function Home() {
  return (
    <main className={styles.container}>
      <Hero />
      <SearchSection />
      <BottomNav />
    </main>
  );
}
