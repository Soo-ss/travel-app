import { useCallback, useState } from "react";
import * as Cesium from "cesium";

import CesiumViewer from "./components/CesiumViewer";
import AiPanel from "./components/AiPanel";
import { askTravelAI } from "./services/ai";
import { drawRoute } from "./components/RouteLayer";
import Home from "./components/Home";

export default function App() {
  const [viewer, setViewer] = useState<Cesium.Viewer | null>(null);

  const handleAskAI = useCallback(
    async (message: string) => {
      if (!viewer) return;

      const result = await askTravelAI(message);
      drawRoute(viewer, result.route);
    },
    [viewer],
  );

  return (
    <>
      {/* <CesiumViewer onReady={setViewer} />
      <AiPanel onSubmit={handleAskAI} /> */}
      <Home />
    </>
  );
}
