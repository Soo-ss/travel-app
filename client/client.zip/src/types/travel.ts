export interface LatLng {
  lat: number;
  lng: number;
}

export interface TravelRoute {
  route: LatLng[];
  summary: string;
}
