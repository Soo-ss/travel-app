// 서버 AI 호출
import type { TravelRoute } from "../types/travel";

export async function askTravelAI(message: string): Promise<TravelRoute> {
  const res = await fetch("http://localhost:3000/api/travel/insight", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ message }),
  });

  if (!res.ok) {
    throw new Error("AI request failed");
  }

  return res.json();
}
