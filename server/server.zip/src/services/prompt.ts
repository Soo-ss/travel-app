// 프롬프트 빌더
export function buildTravelPrompt({
  userMessage,
  travelContext,
}: {
  userMessage: string;
  travelContext: string;
}) {
  return [
    {
      role: "system",
      content:
        "You are an AI travel assistant. Provide concise and practical advice.",
    },
    {
      role: "assistant",
      content: `Travel Context:\n${travelContext}`,
    },
    {
      role: "user",
      content: userMessage,
    },
  ];
}
