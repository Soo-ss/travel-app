import { Router } from "express";
import { createChatCompletion } from "../services/openai";
import { buildTravelPrompt } from "../services/prompt";

const router = Router();

router.post("/insight", async (req, res) => {
  const { message, itinerary } = req.body;

  const prompt = buildTravelPrompt({
    userMessage: message,
    travelContext: JSON.stringify(itinerary),
  });

  const completion = await createChatCompletion(prompt);

  // 👉 Cesium에서 바로 쓸 JSON 포맷
  res.json({
    insight: completion.choices[0].message.content,
    route: itinerary.route, // lng/lat array
  });
});

export default router;
