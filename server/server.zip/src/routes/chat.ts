import { Router } from "express";
import { createChatCompletion } from "../services/openai";

const router = Router();

router.post("/", async (req, res) => {
  const { message } = req.body;

  const completion = await createChatCompletion([
    { role: "user", content: message },
  ]);

  res.json({
    answer: completion.choices[0].message.content,
  });
});

export default router;
