import express from "express";
import cors from "cors";
import chatRouter from "./routes/chat";
import travelRouter from "./routes/travel";

const app = express();
const myPort = process.env.PORT;

app.use(cors());
app.use(express.json());

app.use("/api/chat", chatRouter);
app.use("/api/travel", travelRouter);

app.listen(myPort, () => {
  console.log(`AI Server running on http://localhost:${myPort}`);
});
